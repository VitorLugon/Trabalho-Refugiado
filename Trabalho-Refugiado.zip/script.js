 var map = new mapboxgl.Map({
        container: 'map',
        style: 'mapbox://styles/mapbox/streets-v11',
        center:  [-20.3305,  -40.2922],
        zoom: 18,
      })